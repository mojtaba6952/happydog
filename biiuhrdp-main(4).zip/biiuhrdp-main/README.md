<p align="center">
<img src="https://media.giphy.com/media/4dM1U76aAQ3dbE6bc3/giphy.gif" alt="GIF" width="128" height="128"/>
</p>
<p align="center">
<a href="#"><img title="VPS/RDP GRÁTIS" src="https://img.shields.io/badge/VPS/RDP GRÁTIS-green?colorA=%23ff0000&colorB=%23017e40&style=for-the-badge"></a>
</p>
<p align="center">
<a href="https://github.com/Drakezin"><img title="Criador" src="https://img.shields.io/badge/Criador-Drakezin-orange.svg?style=for-the-badge&logo=github"></a>
</p>


#### Tutorial YouTube

* Link: `https://www.youtube.com/watch?v=8rFL3mbsjJM&t=27s`

#### Tutorial PT/BR
1. Obrigatório criar a conta em: `https://dashboard.ngrok.com/signup`
2. Ir nas "Settings" depois em "Secrets" e criar um repositorio secreto com o nome `NGROK_AUTH_TOKEN`
3. Coloque o token de: `https://dashboard.ngrok.com/get-started/your-authtoken` no repositorio secreto
4. Vai em "Actions" e procure "BiiuhRDP".

#### Tutorial EN
1. Account must be created at: `https://dashboard.ngrok.com/signup`
2. Go to "Settings" then "Secrets" and create a secret repository named `NGROK_AUTH_TOKEN`
3. Place the token: `https://dashboard.ngrok.com/get-started/your-authtoken` in the secret repository
4. Go to "Actions" and look for "BiiuhRDP".

#### Config.
- IP: `https://dashboard.ngrok.com/endpoints/status`
- User: `runneradmin`
- Senha/Password: `Biiuh2021`
- Tempo/Time: `6 horas/hours`

#### Config. PC
- RAM: `7gb`
- Cores: `2`
